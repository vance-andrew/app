package com.app.virtualcampus;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class FacultyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);

        String PROF_ID = getIntent().getStringExtra("PROF_ID");
        String NAME = getIntent().getStringExtra("NAME");
        String PIC = getIntent().getStringExtra("PIC");
        String CLASS_PIC = getIntent().getStringExtra("CLASS_PIC");
        String BUILD_PIC = getIntent().getStringExtra("BUILD_PIC");
        String BUILDING_ID = getIntent().getStringExtra("BUILDING_ID");
        String FLOOR = getIntent().getStringExtra("FLOOR");
        String ROOM = getIntent().getStringExtra("ROOM");
        String DEPT = getIntent().getStringExtra("DEPT");
        String CLASS_TAUGHT = getIntent().getStringExtra("CLASS_TAUGHT");

        RelativeLayout main_view = findViewById(R.id.main_view);
        loadImage(BUILD_PIC , main_view);

        RelativeLayout iv_professor = findViewById(R.id.iv_professor);
        loadImage(PIC , iv_professor);

        TextView name = findViewById(R.id.name);
        TextView buildingID = findViewById(R.id.buildingID);
        TextView floor = findViewById(R.id.floor);
        TextView room = findViewById(R.id.room);
        TextView dept = findViewById(R.id.dept);
        TextView class_taught = findViewById(R.id.class_taught);

        name.setText("Name: " + NAME);
        dept.setText("Department: " + DEPT);
        room.setText("Room: " + ROOM);
        class_taught.setText("Class Taught: " + CLASS_TAUGHT);
        buildingID.setText("Building: " + BUILDING_ID);
        floor.setText("Floor: " + FLOOR);

    }

    private void loadImage(String name , RelativeLayout main_view)
    {
        try {
            // get input stream
            InputStream ims = getAssets().open(name);
            // load image as Drawable
            Drawable d = Drawable.createFromStream(ims, null);
            // set image to ImageView

            final int sdk = android.os.Build.VERSION.SDK_INT;
            if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
                main_view.setBackgroundDrawable(d);
            } else {
                main_view.setBackground(d);
            }

        }
        catch(IOException ex) {
            return;
        }
    }
}
