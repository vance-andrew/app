package com.app.virtualcampus.Helper;

public class AppConstants {

    public static final String TAG = "VirtualCampus";

}
