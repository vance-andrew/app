package com.app.virtualcampus;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.app.virtualcampus.Helper.AppConstants;
import com.app.virtualcampus.Helper.DBController;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {

    DBController mDB;
    String build_pic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setupUI(findViewById(R.id.main_view));

        mDB = new DBController(getApplicationContext());

        final String build_id = getIntent().getStringExtra("build_id");
        String build_name = getIntent().getStringExtra("build_name");
        String picName = getIntent().getStringExtra("pic_name");
        build_pic = picName;

        Log.v(AppConstants.TAG , "build_id: " + build_id);
        Log.v(AppConstants.TAG , "picName: " + picName);

        RelativeLayout main_view = findViewById(R.id.main_view);
        loadImage(picName , main_view);

        final ArrayList<String> classes = mDB.getclasses(build_id);
        Log.w(AppConstants.TAG , "classes size: " + classes.size());

        TextView tv_buildingName = findViewById(R.id.tv_buildingName);
        tv_buildingName.setText(build_name);

        final EditText search_edittext = findViewById(R.id.search_edittext);

        final LinearLayout btn_menu = findViewById(R.id.btn_menu);
        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu menu = new PopupMenu(DetailActivity.this, v);
                for(int i=0 ;i < classes.size(); i++)
                {
                    MenuItem item =  menu.getMenu().add(classes.get(i).toString());
                    item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            Log.i(AppConstants.TAG , "item: " + item.getTitle());
                            Cursor cursor = mDB.searchClass(item.getTitle().toString() , build_id);
                            Log.w(AppConstants.TAG , "mCursor: " + cursor.getCount());
                            if(cursor.getCount() > 0)
                            {
                                if(cursor.moveToFirst())
                                {
                                    String CLASS_ID = cursor.getString(cursor.getColumnIndex(DBController.CLASS_ID));
                                    String NAME = cursor.getString(cursor.getColumnIndex(DBController.NAME));
                                    String PIC = cursor.getString(cursor.getColumnIndex(DBController.PIC));
                                    String BUILDING_ID = cursor.getString(cursor.getColumnIndex(DBController.BUILDING_ID));
                                    String TIME = cursor.getString(cursor.getColumnIndex(DBController.TIME));
                                    String FLOOR = cursor.getString(cursor.getColumnIndex(DBController.FLOOR));
                                    String ROOM = cursor.getString(cursor.getColumnIndex(DBController.ROOM));

                                    Log.w(AppConstants.TAG , "NAME: " + NAME + "  BUILDING_ID: " + BUILDING_ID);

                                    Intent i = new Intent(DetailActivity.this , ClassActivity.class);
                                    i.putExtra("CLASS_ID" , CLASS_ID);
                                    i.putExtra("NAME" , NAME);
                                    i.putExtra("PIC" , PIC);
                                    i.putExtra("BUILDING_ID" , BUILDING_ID);
                                    i.putExtra("TIME" , TIME);
                                    i.putExtra("FLOOR" , FLOOR);
                                    i.putExtra("ROOM" , ROOM);
                                    startActivity(i);
                                }
                            }


                            return false;
                        }
                    });
                }
                menu.show();

            }
        });

        ImageView btn_search = findViewById(R.id.btn_search);
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = mDB.searchClass(search_edittext.getText().toString() , build_id);

                if(cursor.getCount() > 0)
                {
                    if(cursor.moveToFirst())
                    {
                        String CLASS_ID = cursor.getString(cursor.getColumnIndex(DBController.CLASS_ID));
                        String NAME = cursor.getString(cursor.getColumnIndex(DBController.NAME));
                        String PIC = cursor.getString(cursor.getColumnIndex(DBController.PIC));
                        String BUILDING_ID = cursor.getString(cursor.getColumnIndex(DBController.BUILDING_ID));
                        String TIME = cursor.getString(cursor.getColumnIndex(DBController.TIME));
                        String FLOOR = cursor.getString(cursor.getColumnIndex(DBController.FLOOR));
                        String ROOM = cursor.getString(cursor.getColumnIndex(DBController.ROOM));

                        Log.w(AppConstants.TAG , "NAME: " + NAME + "  BUILDING_ID: " + BUILDING_ID);

                        Intent i = new Intent(DetailActivity.this , ClassActivity.class);
                        i.putExtra("CLASS_ID" , CLASS_ID);
                        i.putExtra("NAME" , NAME);
                        i.putExtra("PIC" , PIC);
                        i.putExtra("BUILDING_ID" , BUILDING_ID);
                        i.putExtra("TIME" , TIME);
                        i.putExtra("FLOOR" , FLOOR);
                        i.putExtra("ROOM" , ROOM);
                        startActivity(i);
                    }
                }
                else
                {
                    Cursor cursorFaculty = mDB.searchFaculty(search_edittext.getText().toString().toLowerCase() , build_id);
                    Log.i(AppConstants.TAG , "cursorFaculty: " + cursorFaculty.getCount());

                    if(cursorFaculty.getCount() > 0) {
                        if (cursorFaculty.moveToFirst()) {
                            String PROF_ID = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.PROF_ID));
                            String NAME = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.NAME));
                            String DESIGNATION = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.DESIGNATION));
                            String DEPT = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.DEPT));
                            String CLASS_TAUGHT = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.CLASS_TAUGHT));
                            String FLOOR = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.FLOOR));
                            String ROOM = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.ROOM));
                            String BUILDING_ID = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.BUILDING_ID));
                            String PIC = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.PIC));
                            String CLASS_PIC = cursorFaculty.getString(cursorFaculty.getColumnIndex(DBController.CLASS_PIC));


                            Log.w(AppConstants.TAG , "NAME: " + NAME + "  BUILDING_ID: " + BUILDING_ID);
                            Log.w(AppConstants.TAG , "PIC: " + PIC + "         CLASS_PIC: " + CLASS_PIC);

                            Intent i = new Intent(DetailActivity.this , FacultyActivity.class);
                            i.putExtra("PROF_ID" , PROF_ID);
                            i.putExtra("NAME" , NAME);
                            i.putExtra("PIC" , PIC);
                            i.putExtra("DEPT" , DEPT);
                            i.putExtra("CLASS_TAUGHT" , CLASS_TAUGHT);
                            i.putExtra("BUILDING_ID" , BUILDING_ID);
                            i.putExtra("DESIGNATION" , DESIGNATION);
                            i.putExtra("FLOOR" , FLOOR);
                            i.putExtra("ROOM" , ROOM);
                            i.putExtra("PIC" , PIC);
                            i.putExtra("CLASS_PIC" , CLASS_PIC);
                            i.putExtra("BUILD_PIC" , build_pic);

                            startActivity(i);

                        }
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"No record found.",Toast.LENGTH_LONG).show();

                    }
                }
            }
        });

    }

    private void loadImage(String name , RelativeLayout main_view)
    {
        try {
            // get input stream
            InputStream ims = getAssets().open(name);
            // load image as Drawable
            Drawable d = Drawable.createFromStream(ims, null);
            // set image to ImageView

            final int sdk = android.os.Build.VERSION.SDK_INT;
            if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
                main_view.setBackgroundDrawable(d);
            } else {
                main_view.setBackground(d);
            }

        }
        catch(IOException ex) {
            return;
        }
    }

    public void setupUI(View view) {

        //Set up touch listener for non-text box views to hide keyboard.
        if(!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(DetailActivity.this);
                    return false;
                }
            });
        }

        //If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView);
            }
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        try
        {
            InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
        catch (Exception e){}

    }
}
